import React, { useState, useEffect, useRef } from "react";
import "./Chatbot.css";
import QuestionAnswerIcon from '@mui/icons-material/QuestionAnswer';
import SendIcon from '@mui/icons-material/Send';
import CloseIcon from '@mui/icons-material/Close';
import SmartToyIcon from '@mui/icons-material/SmartToy';
import chatbotIcon from "../../assets/images/chatbotIcon.png";

const Chatbot = () => {
    const [showChatbot, setShowChatbot] = useState(false);
    const [userMessage, setUserMessage] = useState("");
    const [chatMessages, setChatMessages] = useState([
        {
            message: "Hi there 👋\nHow can I help you today?",
            className: "incoming",
        },
    ]);
    const chatboxRef = useRef(null);

    const API_KEY = "PASTE-YOUR-API-KEY"; // Paste your API key here

    const createChatLi = (message, className) => {
        return { message, className };
    };

    const generateResponse = (chatElement) => {
        const API_URL = "https://api.openai.com/v1/chat/completions";

        const requestOptions = {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${API_KEY}`,
            },
            body: JSON.stringify({
                model: "gpt-3.5-turbo",
                messages: [{ role: "user", content: userMessage }],
            }),
        };

        fetch(API_URL, requestOptions)
            .then((res) => res.json())
            .then((data) => {
                const updatedMessages = chatMessages.map((msg) =>
                    msg === chatElement
                        ? { ...msg, message: data.choices[0].message.content.trim() }
                        : msg
                );
                setChatMessages(updatedMessages);
            })
            .catch(() => {
                const updatedMessages = chatMessages.map((msg) =>
                    msg === chatElement
                        ? { ...msg, message: "Oops! Something went wrong. Please try again.", className: "incoming error" }
                        : msg
                );
                setChatMessages(updatedMessages);
            })
            .finally(() => {
                chatboxRef.current.scrollTo(0, chatboxRef.current.scrollHeight);
            });
    };

    const handleChat = () => {
        if (!userMessage.trim()) return;

        const outgoingMessage = createChatLi(userMessage, "outgoing");
        setChatMessages([...chatMessages, outgoingMessage]);

        setUserMessage("");

        setTimeout(() => {
            const incomingMessage = createChatLi("Thinking...", "incoming");
            setChatMessages((prevMessages) => {
                const newMessages = [...prevMessages, incomingMessage];
                generateResponse(incomingMessage);
                return newMessages;
            });
        }, 600);
    };

    useEffect(() => {
        if (chatboxRef.current) {
            chatboxRef.current.scrollTo(0, chatboxRef.current.scrollHeight);
        }
    }, [chatMessages]);

    return (<>
        <body className="show-chatbot">
            {showChatbot
                ? <span className="chatbot-close" onClick={() => setShowChatbot(!showChatbot)}><CloseIcon></CloseIcon></span>
                : <img src={chatbotIcon} alt="ChatBot Icon" className="chatbot-icon" onClick={() => setShowChatbot(!showChatbot)} />
            }


            {showChatbot && (
                <div className="chatbot">
                    <header>
                        <h2>LENS Chatbot</h2>
                        <span className="" onClick={() => setShowChatbot(false)}><CloseIcon /></span>
                    </header>
                    <ul className="chatbox" ref={chatboxRef}>

                        {chatMessages.map((msg, index) => (
                            <li key={index} className={`chat ${msg.className}`}>
                                {msg.className === "incoming" && (
                                    <span className=""><SmartToyIcon /></span>
                                )}
                                <p className={msg.className === "incoming error" ? "error" : ""}>{msg.message}</p>
                            </li>
                        ))}
                    </ul>
                    <div className="chat-input">
                        <textarea placeholder="Enter a message..." spellcheck="false" required
                            value={userMessage}
                            onChange={(e) => setUserMessage(e.target.value)}
                            onKeyDown={(e) => {
                                if (e.key === "Enter" && !e.shiftKey && window.innerWidth > 800) {
                                    e.preventDefault();
                                    handleChat();
                                }
                            }}>
                        </textarea>
                        <span id="send-btn" className="" onClick={handleChat}><SendIcon /></span>
                    </div>
                </div>
            )}
        </body>
    </>
    );
};

export default Chatbot;
